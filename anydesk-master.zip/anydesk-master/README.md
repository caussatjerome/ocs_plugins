# Anydesk
Retrieve version and ID of Anydesk